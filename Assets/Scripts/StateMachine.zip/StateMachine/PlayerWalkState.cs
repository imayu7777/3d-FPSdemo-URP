﻿using System.Collections;
using UnityEngine;


public class PlayerWalkState : IState
{
    Player player;
    public PlayerWalkState(Player player)
    {
        this.player = player;
    }
    void OnEnter()
    {
        player.anim.Play("WalkForwardBattle");
    }
    public void OnUpdate()
    {

    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}

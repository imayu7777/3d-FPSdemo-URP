﻿using System.Collections;
using UnityEngine;


public class PlayerAttackState : IState
{
    Player player;
    public PlayerAttackState(Player player)
    {
        this.player = player;
    }
    void OnEnter()
    {
        player.anim.SetTrigger("isAttack");
    }
    public void OnUpdate()
    {

    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}

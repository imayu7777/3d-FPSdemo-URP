﻿using System.Collections;
using UnityEngine;


public class PlayerRunState : IState
{
    Player Player;
    public PlayerRunState(Player player)
    {
        this.Player = player;
    }
    void OnEnter()
    {

    }
    public void OnUpdate()
    {

    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}

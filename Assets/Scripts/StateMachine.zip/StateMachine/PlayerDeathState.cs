﻿using System.Collections;
using UnityEngine;


public class PlayerDeathState : IState
{
    Player Player;
    public PlayerDeathState(Player player)
    {
        this.Player = player;
    }
    void OnEnter()
    {

    }
    public void OnUpdate()
    {

    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}

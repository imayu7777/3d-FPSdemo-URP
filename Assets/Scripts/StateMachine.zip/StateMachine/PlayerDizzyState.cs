﻿using System.Collections;
using UnityEngine;


public class PlayerDizzyState : IState
{
    Player Player;
    public PlayerDizzyState(Player player)
    {
        this.Player = player;
    }
    void OnEnter()
    {

    }
    public void OnUpdate()
    {

    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}

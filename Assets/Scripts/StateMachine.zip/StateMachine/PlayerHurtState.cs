﻿using System.Collections;
using UnityEngine;


public class PlayerHurtState : IState
{
    Player Player;
    public PlayerHurtState(Player player)
    {
        this.Player = player;
    }
    void OnEnter()
    {

    }
    public void OnUpdate()
    {

    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}

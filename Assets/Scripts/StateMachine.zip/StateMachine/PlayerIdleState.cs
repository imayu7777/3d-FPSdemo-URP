﻿using System.Collections;
using UnityEngine;


public class PlayerIdleState : IState
{
    Player player;
    public PlayerIdleState(Player player)
    {
        this.player = player;
    }
    void OnEnter()
    {

    }
    public void OnUpdate()
    {
        if (player.inputDirection != Vector3.zero)
        {
            player.TransitionState(PlayerStateType.Walk);
        }
    }
    public void OnFixedUpdate()
    {

    }
    public void OnExit()
    {

    }
}
